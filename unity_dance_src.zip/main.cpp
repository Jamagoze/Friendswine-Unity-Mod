#include <jni.h>
#include <dlfcn.h>
#include <unistd.h>
#include <fcntl.h>
#include <pthread.h>
#include <sys/syscall.h>
#include <android/log.h>
#include <cmath>
#include <ctime>
#include <cstdint>
#include <cstring>
#include <cstdlib>
#include <string>
#include <vector>
#include <atomic>
#include <unordered_map>
#include <unordered_set>
#include "zygisk.hpp"
#include "dobby.h"

#define LOG(...) __android_log_print(ANDROID_LOG_INFO, "UnityDance", __VA_ARGS__)

// ---------------- config ----------------
struct Cfg {
    float speed = 2.f, bob = 0.1f, sway = 8.f, shift = 0.05f, squash = 0.08f;
    int sync = 0, maxn = 200, ui = 0;
    std::vector<std::string> apps;
} C;

static std::string trim(std::string s) {
    size_t a = s.find_first_not_of(" \t\r\n");
    if (a == std::string::npos) return "";
    size_t b = s.find_last_not_of(" \t\r\n");
    return s.substr(a, b - a + 1);
}

static void parseCfg(const std::string &s) {
    C.apps.clear();
    size_t p = 0;
    while (p < s.size()) {
        size_t e = s.find('\n', p);
        if (e == std::string::npos) e = s.size();
        std::string l = trim(s.substr(p, e - p));
        p = e + 1;
        if (l.empty() || l[0] == '#') continue;
        size_t q = l.find('=');
        if (q == std::string::npos) continue;
        std::string k = trim(l.substr(0, q)), v = trim(l.substr(q + 1));
        if (k == "app") C.apps.push_back(v);
        else if (k == "speed") C.speed = atof(v.c_str());
        else if (k == "bob") C.bob = atof(v.c_str());
        else if (k == "sway") C.sway = atof(v.c_str());
        else if (k == "shift") C.shift = atof(v.c_str());
        else if (k == "squash") C.squash = atof(v.c_str());
        else if (k == "sync") C.sync = atoi(v.c_str());
        else if (k == "max") C.maxn = atoi(v.c_str());
        else if (k == "ui") C.ui = atoi(v.c_str());
    }
}

// ---------------- il2cpp ----------------
static void *(*f_domain_get)();
static void **(*f_get_asm)(void *, size_t *);
static void *(*f_asm_image)(void *);
static void *(*f_class_from_name)(void *, const char *, const char *);
static void *(*f_get_method)(void *, const char *, int);
static void *(*f_class_type)(void *);
static void *(*f_type_object)(void *);
static void *(*f_invoke)(void *, void *, void **, void **);
static void *(*f_unbox)(void *);
static void *(*f_resolve_icall)(const char *);
static uint32_t (*f_gc_new)(void *, bool);
static void *(*f_gc_get)(uint32_t);
static void (*f_gc_free)(uint32_t);
static size_t (*f_arr_len)(void *);
static void *(*f_thread_attach)(void *);
static void (*f_thread_detach)(void *);

static void *m_get_transform, *m_gpos, *m_spos, *m_geul, *m_seul, *m_gscl, *m_sscl;
static void *m_find; static int m_find_args;
static void *g_find_cls;
static std::vector<uint32_t> g_types; // gchandles of System.Type objects

static void *findClass(const char *ns, const char *name) {
    void *dom = f_domain_get();
    if (!dom) return nullptr;
    size_t n = 0;
    void **as = f_get_asm(dom, &n);
    for (size_t i = 0; i < n; i++) {
        void *img = f_asm_image(as[i]);
        if (!img) continue;
        void *c = f_class_from_name(img, ns, name);
        if (c) return c;
    }
    return nullptr;
}

struct Item { uint32_t h = 0; float ox = 0, oy = 0, orot = 0, fx = 1, fy = 1, phase = 0; };
static std::vector<Item> items;
static double lastTick = 0, lastRefresh = -10;

static double mono() {
    timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec / 1e9;
}

static bool getV3(void *m, void *tr, float *o) {
    void *exc = nullptr;
    void *b = f_invoke(m, tr, nullptr, &exc);
    if (exc || !b) return false;
    memcpy(o, f_unbox(b), 12);
    return true;
}
static bool setV3(void *m, void *tr, const float *v) {
    void *exc = nullptr;
    void *a[1] = {(void *) v};
    f_invoke(m, tr, a, &exc);
    return !exc;
}

static void refresh() {
    std::unordered_map<void *, Item> old;
    for (auto &i : items) {
        void *t = f_gc_get(i.h);
        if (t) old[t] = i;
        f_gc_free(i.h);
    }
    items.clear();
    std::unordered_set<void *> seen;
    for (uint32_t th : g_types) {
        void *tobj = f_gc_get(th);
        if (!tobj) continue;
        void *exc = nullptr;
        void *arr = nullptr;
        if (m_find_args == 1) {
            void *a[1] = {tobj};
            arr = f_invoke(m_find, nullptr, a, &exc);
        } else {
            int sort = 0;
            void *a[2] = {tobj, &sort};
            arr = f_invoke(m_find, nullptr, a, &exc);
        }
        if (exc || !arr) continue;
        size_t n = f_arr_len(arr);
        void **data = (void **) ((char *) arr + 4 * sizeof(void *));
        for (size_t k = 0; k < n && (int) items.size() < C.maxn; k++) {
            void *comp = data[k];
            if (!comp) continue;
            void *e2 = nullptr;
            void *tr = f_invoke(m_get_transform, comp, nullptr, &e2);
            if (e2 || !tr || seen.count(tr)) continue;
            seen.insert(tr);
            Item it;
            auto f = old.find(tr);
            if (f != old.end()) it = f->second;
            else it.phase = C.sync ? 0.f : (float) (((uintptr_t) tr >> 4) % 628) / 100.f;
            it.h = f_gc_new(tr, false);
            items.push_back(it);
        }
    }
}

static bool applyItem(Item &it, double now) {
    void *tr = f_gc_get(it.h);
    if (!tr) return false;
    double ph = fmod(now * C.speed, 1.0) * 6.2831853 + it.phase;
    float s = sinf((float) ph);
    float bob = fabsf(s) * C.bob;
    float dx = s * C.shift;
    float rot = s * C.sway;
    float sq = sinf(2.f * (float) ph) * C.squash;
    float fx = 1.f - sq * 0.5f, fy = 1.f + sq;
    float v[3];
    if (!getV3(m_gpos, tr, v)) return false;
    v[0] += dx - it.ox; v[1] += bob - it.oy;
    if (!setV3(m_spos, tr, v)) return false;
    if (!getV3(m_geul, tr, v)) return false;
    v[2] += rot - it.orot;
    if (!setV3(m_seul, tr, v)) return false;
    if (!getV3(m_gscl, tr, v)) return false;
    v[0] *= fx / it.fx; v[1] *= fy / it.fy;
    if (!setV3(m_sscl, tr, v)) return false;
    it.ox = dx; it.oy = bob; it.orot = rot; it.fx = fx; it.fy = fy;
    return true;
}

static void tick() {
    double now = mono();
    if (now - lastTick < 1.0 / 60.0) return;
    lastTick = now;
    if (now - lastRefresh > 1.0) { lastRefresh = now; refresh(); }
    for (size_t i = 0; i < items.size();) {
        if (!applyItem(items[i], now)) { f_gc_free(items[i].h); items.erase(items.begin() + i); }
        else i++;
    }
}

static std::atomic<bool> g_ready{false};
static std::atomic<int> g_tid{0};
static double g_start = 0;
static float (*orig_dt)();

static float hook_dt() {
    float r = orig_dt();
    static thread_local bool busy = false;
    if (g_ready.load() && !busy) {
        int tid = (int) syscall(SYS_gettid);
        int cur = g_tid.load();
        if (cur == 0 && mono() > g_start + 5.0) { g_tid.store(tid); cur = tid; }
        if (tid == cur) { busy = true; tick(); busy = false; }
    }
    return r;
}

static void *init_thread(void *) {
    void *h = nullptr;
    for (int i = 0; i < 120 && !h; i++) {
        h = dlopen("libil2cpp.so", RTLD_NOW | RTLD_NOLOAD);
        if (!h) sleep(1);
    }
    if (!h) return nullptr;
#define SYM(v, n) v = (decltype(v)) dlsym(h, n); if (!v) { LOG("missing %s", n); return nullptr; }
    SYM(f_domain_get, "il2cpp_domain_get")
    SYM(f_get_asm, "il2cpp_domain_get_assemblies")
    SYM(f_asm_image, "il2cpp_assembly_get_image")
    SYM(f_class_from_name, "il2cpp_class_from_name")
    SYM(f_get_method, "il2cpp_class_get_method_from_name")
    SYM(f_class_type, "il2cpp_class_get_type")
    SYM(f_type_object, "il2cpp_type_get_object")
    SYM(f_invoke, "il2cpp_runtime_invoke")
    SYM(f_unbox, "il2cpp_object_unbox")
    SYM(f_resolve_icall, "il2cpp_resolve_icall")
    SYM(f_gc_new, "il2cpp_gchandle_new")
    SYM(f_gc_get, "il2cpp_gchandle_get_target")
    SYM(f_gc_free, "il2cpp_gchandle_free")
    SYM(f_arr_len, "il2cpp_array_length")
    SYM(f_thread_attach, "il2cpp_thread_attach")
    SYM(f_thread_detach, "il2cpp_thread_detach")

    void *sprite = nullptr;
    for (int i = 0; i < 90 && !sprite; i++) {
        sleep(1);
        sprite = findClass("UnityEngine", "SpriteRenderer");
    }
    if (!sprite) { LOG("SpriteRenderer not found"); return nullptr; }
    sleep(3);
    void *dom = f_domain_get();
    void *thr = f_thread_attach(dom);

    void *compC = findClass("UnityEngine", "Component");
    void *trC = findClass("UnityEngine", "Transform");
    void *objC = findClass("UnityEngine", "Object");
    if (!compC || !trC || !objC) { LOG("core classes missing"); return nullptr; }
    m_get_transform = f_get_method(compC, "get_transform", 0);
    m_gpos = f_get_method(trC, "get_localPosition", 0);
    m_spos = f_get_method(trC, "set_localPosition", 1);
    m_geul = f_get_method(trC, "get_localEulerAngles", 0);
    m_seul = f_get_method(trC, "set_localEulerAngles", 1);
    m_gscl = f_get_method(trC, "get_localScale", 0);
    m_sscl = f_get_method(trC, "set_localScale", 1);
    m_find = f_get_method(objC, "FindObjectsOfType", 1); m_find_args = 1;
    if (!m_find) { m_find = f_get_method(objC, "FindObjectsByType", 2); m_find_args = 2; }
    if (!m_get_transform || !m_gpos || !m_spos || !m_geul || !m_seul || !m_gscl || !m_sscl || !m_find) {
        LOG("methods missing"); return nullptr;
    }
    g_types.push_back(f_gc_new(f_type_object(f_class_type(sprite)), true));
    if (C.ui) {
        void *img = findClass("UnityEngine.UI", "Image");
        if (img) g_types.push_back(f_gc_new(f_type_object(f_class_type(img)), true));
    }
    f_thread_detach(thr);

    const char *names[] = {"UnityEngine.Time::get_deltaTime()", "UnityEngine.Time::get_unscaledDeltaTime()",
                           "UnityEngine.Time::get_time()"};
    void *addr = nullptr;
    for (auto n : names) { addr = f_resolve_icall(n); if (addr) break; }
    if (!addr) { LOG("icall not found"); return nullptr; }
    g_start = mono();
    if (DobbyHook(addr, (dobby_dummy_func_t) hook_dt, (dobby_dummy_func_t *) &orig_dt) != 0) { LOG("hook failed"); return nullptr; }
    g_ready.store(true);
    LOG("dancing started");
    return nullptr;
}

// ---------------- zygisk ----------------
static bool readFull(int fd, void *b, size_t n) {
    char *p = (char *) b;
    while (n) { ssize_t r = read(fd, p, n); if (r <= 0) return false; p += r; n -= r; }
    return true;
}

class DanceModule : public zygisk::ModuleBase {
public:
    void onLoad(zygisk::Api *a, JNIEnv *e) override { api = a; env = e; }
    void preAppSpecialize(zygisk::AppSpecializeArgs *args) override {
        const char *nm = env->GetStringUTFChars(args->nice_name, nullptr);
        std::string name = nm ? nm : "";
        if (nm) env->ReleaseStringUTFChars(args->nice_name, nm);
        std::string data;
        int fd = api->connectCompanion();
        if (fd >= 0) {
            uint32_t n = 0;
            if (readFull(fd, &n, 4) && n < 65536) { data.resize(n); if (n) readFull(fd, &data[0], n); }
            close(fd);
        }
        parseCfg(data);
        enabled = false;
        for (auto &a : C.apps) if (a == "*" || a == name) enabled = true;
        if (!enabled) api->setOption(zygisk::DLCLOSE_MODULE_LIBRARY);
    }
    void postAppSpecialize(const zygisk::AppSpecializeArgs *) override {
        if (!enabled) return;
        pthread_t t;
        pthread_create(&t, nullptr, init_thread, nullptr);
        pthread_detach(t);
    }
private:
    zygisk::Api *api = nullptr;
    JNIEnv *env = nullptr;
    bool enabled = false;
};

static void companion(int fd) {
    std::string d;
    int f = open("/data/adb/modules/unity_dance/dance.conf", O_RDONLY);
    if (f >= 0) {
        char b[4096]; ssize_t r;
        while ((r = read(f, b, sizeof b)) > 0) d.append(b, r);
        close(f);
    }
    uint32_t n = d.size();
    write(fd, &n, 4);
    if (n) write(fd, d.data(), n);
}

REGISTER_ZYGISK_MODULE(DanceModule)
REGISTER_ZYGISK_COMPANION(companion)
