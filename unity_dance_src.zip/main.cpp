#include <jni.h>
#include <dlfcn.h>
#include <unistd.h>
#include <fcntl.h>
#include <pthread.h>
#include <link.h>
#include <elf.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <android/log.h>
#include <cmath>
#include <ctime>
#include <cstdint>
#include <cstring>
#include <cstdlib>
#include <string>
#include <vector>
#include <atomic>
#include <unordered_map>
#include <unordered_set>
#include "zygisk.hpp"

#define LOG(...) __android_log_print(ANDROID_LOG_INFO, "UnityDance", __VA_ARGS__)

// ---------------- config ----------------
struct Cfg {
    float speed = 2.f, bob = 0.1f, sway = 8.f, shift = 0.05f, squash = 0.08f;
    int sync = 0, maxn = 200, ui = 0;
    std::string target = "sprite,skinned";
    std::vector<std::string> apps;
} C;

static std::string trim(std::string s) {
    size_t a = s.find_first_not_of(" \t\r\n");
    if (a == std::string::npos) return "";
    size_t b = s.find_last_not_of(" \t\r\n");
    return s.substr(a, b - a + 1);
}

static void parseCfg(const std::string &s) {
    C.apps.clear();
    size_t p = 0;
    while (p < s.size()) {
        size_t e = s.find('\n', p);
        if (e == std::string::npos) e = s.size();
        std::string l = trim(s.substr(p, e - p));
        p = e + 1;
        if (l.empty() || l[0] == '#') continue;
        size_t q = l.find('=');
        if (q == std::string::npos) continue;
        std::string k = trim(l.substr(0, q)), v = trim(l.substr(q + 1));
        if (k == "app") C.apps.push_back(v);
        else if (k == "speed") C.speed = atof(v.c_str());
        else if (k == "bob") C.bob = atof(v.c_str());
        else if (k == "sway") C.sway = atof(v.c_str());
        else if (k == "shift") C.shift = atof(v.c_str());
        else if (k == "squash") C.squash = atof(v.c_str());
        else if (k == "sync") C.sync = atoi(v.c_str());
        else if (k == "max") C.maxn = atoi(v.c_str());
        else if (k == "ui") C.ui = atoi(v.c_str());
        else if (k == "target") C.target = v;
    }
}

// ---------------- il2cpp ----------------
static void *(*f_domain_get)();
static void **(*f_get_asm)(void *, size_t *);
static void *(*f_asm_image)(void *);
static void *(*f_class_from_name)(void *, const char *, const char *);
static void *(*f_get_method)(void *, const char *, int);
static void *(*f_class_type)(void *);
static void *(*f_type_object)(void *);
static void *(*f_invoke)(void *, void *, void **, void **);
static void *(*f_unbox)(void *);
static void *(*f_resolve_icall)(const char *);
static uint32_t (*f_gc_new)(void *, bool);
static void *(*f_gc_get)(uint32_t);
static void (*f_gc_free)(uint32_t);
static size_t (*f_arr_len)(void *);
static void *(*f_thread_attach)(void *);
static void (*f_thread_detach)(void *);

static void *m_get_transform, *m_gpos, *m_spos, *m_geul, *m_seul, *m_gscl, *m_sscl;
static void *m_find; static int m_find_args;
static void *g_find_cls;
struct TType { uint32_t h; bool root; int axis; };
static std::vector<TType> g_types;
static void *m_get_root;

static void *findClass(const char *ns, const char *name) {
    void *dom = f_domain_get();
    if (!dom) return nullptr;
    size_t n = 0;
    void **as = f_get_asm(dom, &n);
    for (size_t i = 0; i < n; i++) {
        void *img = f_asm_image(as[i]);
        if (!img) continue;
        void *c = f_class_from_name(img, ns, name);
        if (c) return c;
    }
    return nullptr;
}

struct Item {
    uint32_t h = 0; int axis = 2;
    float ox = 0, oy = 0, orot = 0, fx = 1, fy = 1, phase = 0;
    bool has = false;
    float lp[3] = {0}, le[3] = {0}, ls[3] = {0};
};
static std::vector<Item> items;
static double lastTick = 0, lastRefresh = -10;

static double mono() {
    timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec / 1e9;
}

static bool getV3(void *m, void *tr, float *o) {
    void *exc = nullptr;
    void *b = f_invoke(m, tr, nullptr, &exc);
    if (exc || !b) return false;
    memcpy(o, f_unbox(b), 12);
    return true;
}
static bool setV3(void *m, void *tr, const float *v) {
    void *exc = nullptr;
    void *a[1] = {(void *) v};
    f_invoke(m, tr, a, &exc);
    return !exc;
}
static bool nearV(const float *a, const float *b) {
    for (int i = 0; i < 3; i++) if (fabsf(a[i] - b[i]) > 1e-4f * (1.f + fabsf(b[i]))) return false;
    return true;
}
static bool nearA(const float *a, const float *b) {
    for (int i = 0; i < 3; i++) {
        float d = fmodf(fabsf(a[i] - b[i]), 360.f);
        if (d > 180.f) d = 360.f - d;
        if (d > 0.05f) return false;
    }
    return true;
}

static void refresh() {
    std::unordered_map<void *, Item> old;
    for (auto &i : items) {
        void *t = f_gc_get(i.h);
        if (t) old[t] = i;
        f_gc_free(i.h);
    }
    items.clear();
    std::unordered_set<void *> seen;
    for (auto &tt : g_types) {
        void *tobj = f_gc_get(tt.h);
        if (!tobj) continue;
        void *exc = nullptr;
        void *arr = nullptr;
        if (m_find_args == 1) {
            void *a[1] = {tobj};
            arr = f_invoke(m_find, nullptr, a, &exc);
        } else {
            int sort = 0;
            void *a[2] = {tobj, &sort};
            arr = f_invoke(m_find, nullptr, a, &exc);
        }
        if (exc || !arr) continue;
        size_t n = f_arr_len(arr);
        void **data = (void **) ((char *) arr + 4 * sizeof(void *));
        for (size_t k = 0; k < n && (int) items.size() < C.maxn; k++) {
            void *comp = data[k];
            if (!comp) continue;
            void *e2 = nullptr;
            void *tr = f_invoke(m_get_transform, comp, nullptr, &e2);
            if (e2 || !tr) continue;
            if (tt.root && m_get_root) {
                void *e3 = nullptr;
                void *rt = f_invoke(m_get_root, tr, nullptr, &e3);
                if (!e3 && rt) tr = rt;
            }
            if (seen.count(tr)) continue;
            seen.insert(tr);
            Item it;
            auto f = old.find(tr);
            if (f != old.end()) it = f->second;
            else it.phase = C.sync ? 0.f : (float) (((uintptr_t) tr >> 4) % 628) / 100.f;
            it.axis = tt.axis;
            it.h = f_gc_new(tr, false);
            items.push_back(it);
        }
    }
}

// Works whether or not the game rewrites the transform every frame:
// if the value is still what we wrote, remove our old offset first; otherwise the game's value is the base.
static bool applyItem(Item &it, double now) {
    void *tr = f_gc_get(it.h);
    if (!tr) return false;
    double ph = fmod(now * C.speed, 1.0) * 6.2831853 + it.phase;
    float s = sinf((float) ph);
    float bob = fabsf(s) * C.bob;
    float dx = s * C.shift;
    float rot = s * C.sway;
    float sq = sinf(2.f * (float) ph) * C.squash;
    float fx = 1.f - sq * 0.5f, fy = 1.f + sq;
    float v[3];

    if (!getV3(m_gpos, tr, v)) return false;
    if (it.has && nearV(v, it.lp)) { v[0] -= it.ox; v[1] -= it.oy; }
    v[0] += dx; v[1] += bob;
    if (!setV3(m_spos, tr, v)) return false;
    memcpy(it.lp, v, 12);

    if (!getV3(m_geul, tr, v)) return false;
    if (it.has && nearA(v, it.le)) v[it.axis] -= it.orot;
    v[it.axis] += rot;
    if (!setV3(m_seul, tr, v)) return false;
    memcpy(it.le, v, 12);

    if (!getV3(m_gscl, tr, v)) return false;
    if (it.has && nearV(v, it.ls)) { v[0] /= it.fx; v[1] /= it.fy; }
    v[0] *= fx; v[1] *= fy;
    if (!setV3(m_sscl, tr, v)) return false;
    memcpy(it.ls, v, 12);

    it.ox = dx; it.oy = bob; it.orot = rot; it.fx = fx; it.fy = fy; it.has = true;
    return true;
}

static void tick() {
    double now = mono();
    if (now - lastTick < 1.0 / 60.0) return;
    lastTick = now;
    if (now - lastRefresh > 1.0) { lastRefresh = now; refresh(); }
    for (size_t i = 0; i < items.size();) {
        if (!applyItem(items[i], now)) { f_gc_free(items[i].h); items.erase(items.begin() + i); }
        else i++;
    }
}

static std::atomic<bool> g_ready{false};
static std::atomic<int> g_tid{0};
static double g_start = 0;
static void *(*orig_invoke)(void *, void *, void **, void **);

static bool isScriptThread(int tid) {
    int cur = g_tid.load();
    if (cur) return cur == tid;
    static thread_local int checked = 0;
    double now = mono();
    if (now < g_start + 5.0) return false;
    if (checked == 1 && now < g_start + 20.0) return false;
    char path[64], buf[32] = {0};
    snprintf(path, sizeof path, "/proc/self/task/%d/comm", tid);
    int fd = open(path, O_RDONLY);
    if (fd >= 0) { read(fd, buf, sizeof buf - 1); close(fd); }
    checked = 1;
    if (strncmp(buf, "UnityMain", 9) == 0 || now >= g_start + 20.0) { g_tid.store(tid); return true; }
    return false;
}

static void *hook_invoke(void *m, void *o, void **p, void **e) {
    void *r = orig_invoke(m, o, p, e);
    static thread_local bool busy = false;
    if (g_ready.load() && !busy) {
        int tid = (int) syscall(SYS_gettid);
        if (isScriptThread(tid)) { busy = true; tick(); busy = false; }
    }
    return r;
}

#ifdef __LP64__
typedef ElfW(Rela) RelT;
#define R_SYM(i) ELF64_R_SYM(i)
#else
typedef ElfW(Rel) RelT;
#define R_SYM(i) ELF32_R_SYM(i)
#endif

struct PatchCtx { const char *lib, *sym; void *repl; void **orig; bool done; };

static int phdrCb(struct dl_phdr_info *info, size_t, void *data) {
    PatchCtx *c = (PatchCtx *) data;
    if (!info->dlpi_name || !info->dlpi_name[0]) return 0;
    if (c->lib) { if (!strstr(info->dlpi_name, c->lib)) return 0; }
    else if (strstr(info->dlpi_name, "libil2cpp.so") || strstr(info->dlpi_name, "unitydance") || strstr(info->dlpi_name, "zygisk")) return 0;
    uintptr_t base = info->dlpi_addr;
    const ElfW(Dyn) *dyn = nullptr;
    for (int i = 0; i < info->dlpi_phnum; i++)
        if (info->dlpi_phdr[i].p_type == PT_DYNAMIC) dyn = (const ElfW(Dyn) *) (base + info->dlpi_phdr[i].p_vaddr);
    if (!dyn) return 0;
    auto fix = [&](uintptr_t p) { return p < base ? p + base : p; };
    const ElfW(Sym) *symtab = nullptr; const char *strtab = nullptr;
    uintptr_t jmprel = 0, pltsz = 0, rel = 0, relsz = 0;
    for (const ElfW(Dyn) *d = dyn; d->d_tag != DT_NULL; d++) {
        switch (d->d_tag) {
            case DT_SYMTAB: symtab = (const ElfW(Sym) *) fix(d->d_un.d_ptr); break;
            case DT_STRTAB: strtab = (const char *) fix(d->d_un.d_ptr); break;
            case DT_JMPREL: jmprel = fix(d->d_un.d_ptr); break;
            case DT_PLTRELSZ: pltsz = d->d_un.d_val; break;
#ifdef __LP64__
            case DT_RELA: rel = fix(d->d_un.d_ptr); break;
            case DT_RELASZ: relsz = d->d_un.d_val; break;
#else
            case DT_REL: rel = fix(d->d_un.d_ptr); break;
            case DT_RELSZ: relsz = d->d_un.d_val; break;
#endif
        }
    }
    if (!symtab || !strtab) return 0;
    uintptr_t tabs[2][2] = {{jmprel, pltsz}, {rel, relsz}};
    for (auto &t : tabs) {
        if (!t[0]) continue;
        const RelT *r = (const RelT *) t[0];
        size_t n = t[1] / sizeof(RelT);
        for (size_t i = 0; i < n; i++) {
            uint32_t si = R_SYM(r[i].r_info);
            if (!si) continue;
            if (strcmp(strtab + symtab[si].st_name, c->sym) != 0) continue;
            void **slot = (void **) (base + r[i].r_offset);
            long pg = sysconf(_SC_PAGESIZE);
            void *page = (void *) ((uintptr_t) slot & ~(pg - 1));
            mprotect(page, pg, PROT_READ | PROT_WRITE);
            if (!c->done) *c->orig = *slot;
            *slot = c->repl;
            c->done = true;
        }
    }
    return c->lib ? 1 : 0;
}

static void *init_thread(void *) {
    void *h = nullptr;
    for (int i = 0; i < 120 && !h; i++) {
        h = dlopen("libil2cpp.so", RTLD_NOW | RTLD_NOLOAD);
        if (!h) sleep(1);
    }
    if (!h) return nullptr;
#define SYM(v, n) v = (decltype(v)) dlsym(h, n); if (!v) { LOG("missing %s", n); return nullptr; }
    SYM(f_domain_get, "il2cpp_domain_get")
    SYM(f_get_asm, "il2cpp_domain_get_assemblies")
    SYM(f_asm_image, "il2cpp_assembly_get_image")
    SYM(f_class_from_name, "il2cpp_class_from_name")
    SYM(f_get_method, "il2cpp_class_get_method_from_name")
    SYM(f_class_type, "il2cpp_class_get_type")
    SYM(f_type_object, "il2cpp_type_get_object")
    SYM(f_invoke, "il2cpp_runtime_invoke")
    SYM(f_unbox, "il2cpp_object_unbox")
    SYM(f_resolve_icall, "il2cpp_resolve_icall")
    SYM(f_gc_new, "il2cpp_gchandle_new")
    SYM(f_gc_get, "il2cpp_gchandle_get_target")
    SYM(f_gc_free, "il2cpp_gchandle_free")
    SYM(f_arr_len, "il2cpp_array_length")
    SYM(f_thread_attach, "il2cpp_thread_attach")
    SYM(f_thread_detach, "il2cpp_thread_detach")

    void *sprite = nullptr;
    for (int i = 0; i < 90 && !sprite; i++) {
        sleep(1);
        sprite = findClass("UnityEngine", "Transform");
    }
    if (!sprite) { LOG("UnityEngine.Transform not found (il2cpp metadata not ready or stripped/hidden)"); return nullptr; }
    LOG("il2cpp ready");
    sleep(3);
    void *dom = f_domain_get();
    void *thr = f_thread_attach(dom);

    void *compC = findClass("UnityEngine", "Component");
    void *trC = findClass("UnityEngine", "Transform");
    void *objC = findClass("UnityEngine", "Object");
    if (!compC || !trC || !objC) { LOG("core classes missing"); return nullptr; }
    m_get_transform = f_get_method(compC, "get_transform", 0);
    m_gpos = f_get_method(trC, "get_localPosition", 0);
    m_spos = f_get_method(trC, "set_localPosition", 1);
    m_geul = f_get_method(trC, "get_localEulerAngles", 0);
    m_seul = f_get_method(trC, "set_localEulerAngles", 1);
    m_gscl = f_get_method(trC, "get_localScale", 0);
    m_sscl = f_get_method(trC, "set_localScale", 1);
    m_get_root = f_get_method(trC, "get_root", 0);
    m_find = f_get_method(objC, "FindObjectsOfType", 1); m_find_args = 1;
    if (!m_find) { m_find = f_get_method(objC, "FindObjectsByType", 2); m_find_args = 2; }
    if (!m_find) {
        void *resC = findClass("UnityEngine", "Resources");
        if (resC) { m_find = f_get_method(resC, "FindObjectsOfTypeAll", 1); m_find_args = 1; }
    }
    LOG("methods: transform=%p pos=%p eul=%p scl=%p root=%p find=%p", m_get_transform, m_gpos, m_geul, m_gscl, m_get_root, m_find);
    if (!m_get_transform || !m_gpos || !m_spos || !m_geul || !m_seul || !m_gscl || !m_sscl || !m_find) {
        LOG("methods missing"); return nullptr;
    }
    auto addType = [&](const char *ns, const char *nm, bool root, int axis) {
        void *c = findClass(ns, nm);
        if (!c) { LOG("class %s missing", nm); return; }
        g_types.push_back({f_gc_new(f_type_object(f_class_type(c)), true), root, axis});
        LOG("target %s", nm);
    };
    auto has = [&](const char *t) { return C.target.find(t) != std::string::npos; };
    if (has("sprite")) addType("UnityEngine", "SpriteRenderer", false, 2);
    if (has("skinned")) addType("UnityEngine", "SkinnedMeshRenderer", true, 1);
    if (has("mesh")) addType("UnityEngine", "MeshRenderer", true, 1);
    if (C.ui || has("ui")) addType("UnityEngine.UI", "Image", false, 2);
    f_thread_detach(thr);

    PatchCtx pc = {nullptr, "il2cpp_runtime_invoke", (void *) hook_invoke, (void **) &orig_invoke, false};
    for (int i = 0; i < 30 && !pc.done; i++) {
        dl_iterate_phdr(phdrCb, &pc);
        if (!pc.done) sleep(1);
    }
    if (!pc.done) { LOG("il2cpp_runtime_invoke GOT slot not found in any lib"); return nullptr; }
    g_start = mono();
    LOG("hook installed");
    g_ready.store(true);
    LOG("dancing started");
    return nullptr;
}

// ---------------- zygisk ----------------
static bool readFull(int fd, void *b, size_t n) {
    char *p = (char *) b;
    while (n) { ssize_t r = read(fd, p, n); if (r <= 0) return false; p += r; n -= r; }
    return true;
}

class DanceModule : public zygisk::ModuleBase {
public:
    void onLoad(zygisk::Api *a, JNIEnv *e) override { api = a; env = e; }
    void preAppSpecialize(zygisk::AppSpecializeArgs *args) override {
        const char *nm = env->GetStringUTFChars(args->nice_name, nullptr);
        std::string name = nm ? nm : "";
        if (nm) env->ReleaseStringUTFChars(args->nice_name, nm);
        std::string data;
        int fd = api->connectCompanion();
        if (fd >= 0) {
            uint32_t n = 0;
            if (readFull(fd, &n, 4) && n < 65536) { data.resize(n); if (n) readFull(fd, &data[0], n); }
            close(fd);
        }
        parseCfg(data);
        enabled = false;
        for (auto &a : C.apps) if (a == "*" || a == name) enabled = true;
        if (!enabled) api->setOption(zygisk::DLCLOSE_MODULE_LIBRARY);
    }
    void postAppSpecialize(const zygisk::AppSpecializeArgs *) override {
        if (!enabled) return;
        pthread_t t;
        pthread_create(&t, nullptr, init_thread, nullptr);
        pthread_detach(t);
    }
private:
    zygisk::Api *api = nullptr;
    JNIEnv *env = nullptr;
    bool enabled = false;
};

static void companion(int fd) {
    std::string d;
    int f = open("/data/adb/modules/unity_dance/dance.conf", O_RDONLY);
    if (f >= 0) {
        char b[4096]; ssize_t r;
        while ((r = read(f, b, sizeof b)) > 0) d.append(b, r);
        close(f);
    }
    uint32_t n = d.size();
    write(fd, &n, 4);
    if (n) write(fd, d.data(), n);
}

REGISTER_ZYGISK_MODULE(DanceModule)
REGISTER_ZYGISK_COMPANION(companion)
